from django.apps import AppConfig

class Swarch2022iiConfig(AppConfig):
    name = 'swarch2022ii_ms'
