from django.urls import path, include

urlpatterns = [
    path('', include('swarch2022ii_ms.urls')),
]

